# What?

![](https://github.com/busyloop/lolcat/raw/master/ass/nom.jpg)

## Screenshot

![](https://github.com/busyloop/lolcat/raw/master/ass/screenshot.png)

## Installation

### Linux

```bash
$ sudo snap install lolcat
```

### Mac

```bash
$ brew install lolcat
```
